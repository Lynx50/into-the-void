import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.intothevoid.app',
  appName: 'Into the Void',
  webDir: 'dist/public'
};

export default config;
